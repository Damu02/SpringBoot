package com.capgemini.thymeleaf.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import com.capgemini.thymeleaf.model.Employee;

@Controller
public class EmployeeController {
	List<Employee> allEmp = new ArrayList<Employee>();

	public EmployeeController() {
		Employee e1 = new Employee("100", "Raj", "56000");
		Employee e2 = new Employee("101", "Selva", "66000");
		allEmp.add(e1);
		allEmp.add(e2);
	}

	public String getAllEmployee(Model model) {
		model.addAttribute("alldata", "");
		return "show";
	}
}
