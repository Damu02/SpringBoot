package com.capgemini.serviceprovider.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.serviceprovider.model.Student;

@RestController
public class StudentController {

	@GetMapping(value = "/getStudent")
	public Student getStudentData() {
		Student stu = new Student();
		stu.setName("Janu");
		stu.setPercentage(89);
		stu.setRollNumber(12);

		return stu; //Default Return type is JSON Object
	}
}
