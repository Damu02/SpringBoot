package com.capgemini.usecalculatorservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class ConsumerController {
	@Autowired
	RestTemplate rt;

	@GetMapping(value = "/consume/{no1}/{no2}")
	public String callService(@PathVariable("no1") int no1,
			@PathVariable("no2") int no2) {
		String result = rt.getForObject("http://calculator-service/add/" + no1
				+ "/" + no2, String.class);
		return result;
	}
}
