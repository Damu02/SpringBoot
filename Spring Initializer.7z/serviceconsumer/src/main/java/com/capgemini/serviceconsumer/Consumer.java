package com.capgemini.serviceconsumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.capgemini.serviceconsumer.model.Student;
@Configuration
public class Consumer implements CommandLineRunner{
	@Autowired
	RestTemplate jt;
	
	@Override
	public void run(String... args) throws Exception {
		Student stud = jt.getForObject("http://localhost:8080/getStudent",Student.class);
		
		System.out.println("Data Received from the URL is.."+stud.toString());
	}
	
}
