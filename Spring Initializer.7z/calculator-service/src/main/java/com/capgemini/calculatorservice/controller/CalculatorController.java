package com.capgemini.calculatorservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.calculatorservice.service.Calculator;

@RestController
public class CalculatorController {

	@Autowired
	Calculator calc;

	@GetMapping(value = "add/{no1}/{no2}")
	public String doAddition(@PathVariable("no1") int number1,
			@PathVariable("no2") int number2) {
		int result = calc.sum(number1, number2);

		return "The sum of the result is.." + result;
	}
}
