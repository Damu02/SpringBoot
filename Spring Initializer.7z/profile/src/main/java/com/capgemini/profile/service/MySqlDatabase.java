package com.capgemini.profile.service;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("Development")
public class MySqlDatabase implements Database{

	@Override
	public String getDatabaseName() {

		return "MySQL Database";
	}

}
