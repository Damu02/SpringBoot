package com.capgemini.profile;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

import com.capgemini.profile.service.Database;

@Configuration
public class ConsloeOutput implements CommandLineRunner {
	@Autowired
	Database database;

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Active Profile database is... "
				+ database.getDatabaseName());
	}

}
