package com.capgemini.profile.service;

public interface Database {

	public String getDatabaseName();
}
