package com.capgemini.profile.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.profile.service.Database;

@RestController
public class ProfileController {

	@Autowired
	Database database;

	@GetMapping(value = "/getProfile")
	public String getDatabaseProfile() {
		return database.getDatabaseName();
	}
}
